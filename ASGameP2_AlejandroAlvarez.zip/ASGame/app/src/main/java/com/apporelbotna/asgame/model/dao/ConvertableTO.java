package com.apporelbotna.asgame.model.dao;

/**
 * Created by Jandol on 02/14/2018.
 */

public interface ConvertableTO<T>
{
    T toObject();
}
